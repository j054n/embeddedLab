/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ddf5b5d */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/students/tuc56100/xilinx/lab8/tb_divideby100.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};
static const char *ng3 = "tb_divideby100.txt";
static const char *ng4 = "Mismatch--index %d, expected %b, received %b";
static const char *ng5 = "Simulation complete!!!";



static void Always_30_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;

LAB0:    t1 = (t0 + 3432U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(30, ng0);

LAB4:    xsi_set_current_line(31, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2200);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(32, ng0);
    t2 = (t0 + 3240);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(33, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2200);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(34, ng0);
    t2 = (t0 + 3240);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    goto LAB2;

}

static void Initial_37_1(char *t0)
{
    char t7[8];
    char t16[8];
    char t33[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    char *t40;

LAB0:    t1 = (t0 + 3680U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(37, ng0);

LAB4:    xsi_set_current_line(39, ng0);
    t2 = (t0 + 1720);
    xsi_vlogfile_readmemb(ng3, 0, t2, 0, 0, 0, 0);
    xsi_set_current_line(41, ng0);
    t2 = (t0 + 3488);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(43, ng0);
    xsi_set_current_line(43, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2040);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);

LAB6:    t2 = (t0 + 2040);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 608);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    xsi_vlog_signed_less(t7, 32, t4, 32, t6, 32);
    t5 = (t7 + 4);
    t8 = *((unsigned int *)t5);
    t9 = (~(t8));
    t10 = *((unsigned int *)t7);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB7;

LAB8:    xsi_set_current_line(60, ng0);
    xsi_vlogfile_write(1, 0, 0, ng5, 1, t0);
    xsi_set_current_line(61, ng0);
    xsi_vlog_finish(1);
    goto LAB1;

LAB7:    xsi_set_current_line(43, ng0);

LAB9:    xsi_set_current_line(45, ng0);
    t13 = (t0 + 1720);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t17 = (t0 + 1720);
    t18 = (t17 + 72U);
    t19 = *((char **)t18);
    t20 = (t0 + 1720);
    t21 = (t20 + 64U);
    t22 = *((char **)t21);
    t23 = (t0 + 2040);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    xsi_vlog_generic_get_array_select_value(t16, 3, t15, t19, t22, 2, 1, t25, 32, 1);
    t26 = (t0 + 1880);
    xsi_vlogvar_assign_value(t26, t16, 0, 0, 3);
    xsi_set_current_line(46, ng0);
    t2 = (t0 + 1880);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t7, 0, 8);
    t5 = (t7 + 4);
    t6 = (t4 + 4);
    t8 = *((unsigned int *)t4);
    t9 = (t8 >> 2);
    t10 = (t9 & 1);
    *((unsigned int *)t7) = t10;
    t11 = *((unsigned int *)t6);
    t12 = (t11 >> 2);
    t27 = (t12 & 1);
    *((unsigned int *)t5) = t27;
    t13 = (t0 + 2520);
    xsi_vlogvar_assign_value(t13, t7, 0, 0, 1);
    xsi_set_current_line(47, ng0);
    t2 = (t0 + 1880);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t7, 0, 8);
    t5 = (t7 + 4);
    t6 = (t4 + 4);
    t8 = *((unsigned int *)t4);
    t9 = (t8 >> 1);
    t10 = (t9 & 1);
    *((unsigned int *)t7) = t10;
    t11 = *((unsigned int *)t6);
    t12 = (t11 >> 1);
    t27 = (t12 & 1);
    *((unsigned int *)t5) = t27;
    t13 = (t0 + 2360);
    xsi_vlogvar_assign_value(t13, t7, 0, 0, 1);
    xsi_set_current_line(48, ng0);
    t2 = (t0 + 3488);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB10;
    goto LAB1;

LAB10:    xsi_set_current_line(49, ng0);
    t2 = (t0 + 1320U);
    t3 = *((char **)t2);
    t2 = (t0 + 1880);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    memset(t7, 0, 8);
    t6 = (t7 + 4);
    t13 = (t5 + 4);
    t8 = *((unsigned int *)t5);
    t9 = (t8 >> 0);
    t10 = (t9 & 1);
    *((unsigned int *)t7) = t10;
    t11 = *((unsigned int *)t13);
    t12 = (t11 >> 0);
    t27 = (t12 & 1);
    *((unsigned int *)t6) = t27;
    memset(t16, 0, 8);
    if (*((unsigned int *)t3) != *((unsigned int *)t7))
        goto LAB12;

LAB11:    t14 = (t3 + 4);
    t15 = (t7 + 4);
    if (*((unsigned int *)t14) != *((unsigned int *)t15))
        goto LAB12;

LAB13:    t17 = (t16 + 4);
    t28 = *((unsigned int *)t17);
    t29 = (~(t28));
    t30 = *((unsigned int *)t16);
    t31 = (t30 & t29);
    t32 = (t31 != 0);
    if (t32 > 0)
        goto LAB14;

LAB15:
LAB16:    xsi_set_current_line(55, ng0);
    t2 = (t0 + 4000);
    *((int *)t2) = 1;
    t3 = (t0 + 3712);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB18;
    goto LAB1;

LAB12:    *((unsigned int *)t16) = 1;
    goto LAB13;

LAB14:    xsi_set_current_line(49, ng0);

LAB17:    xsi_set_current_line(51, ng0);
    t18 = (t0 + 2040);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = (t0 + 1880);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    memset(t33, 0, 8);
    t24 = (t33 + 4);
    t25 = (t23 + 4);
    t34 = *((unsigned int *)t23);
    t35 = (t34 >> 0);
    t36 = (t35 & 1);
    *((unsigned int *)t33) = t36;
    t37 = *((unsigned int *)t25);
    t38 = (t37 >> 0);
    t39 = (t38 & 1);
    *((unsigned int *)t24) = t39;
    t26 = (t0 + 1320U);
    t40 = *((char **)t26);
    xsi_vlogfile_write(1, 0, 0, ng4, 4, t0, (char)119, t20, 32, (char)118, t33, 1, (char)118, t40, 1);
    goto LAB16;

LAB18:    xsi_set_current_line(56, ng0);
    t2 = (t0 + 3488);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB19;
    goto LAB1;

LAB19:    xsi_set_current_line(43, ng0);
    t2 = (t0 + 2040);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    memset(t7, 0, 8);
    xsi_vlog_signed_add(t7, 32, t4, 32, t5, 32);
    t6 = (t0 + 2040);
    xsi_vlogvar_assign_value(t6, t7, 0, 0, 32);
    goto LAB6;

}


extern void work_m_00161899019086801744_2546580645_init()
{
	static char *pe[] = {(void *)Always_30_0,(void *)Initial_37_1};
	xsi_register_didat("work_m_00161899019086801744_2546580645", "isim/tb_divideby100_isim_beh.exe.sim/work/m_00161899019086801744_2546580645.didat");
	xsi_register_executes(pe);
}
